"use strict";
$(document).ready(function(){  
    var makeTheChange = function(amount) {
    var quarter = Math.floor(amount / 25);
    amount = amount % 25;
    var dime = Math.floor(amount / 10);
    amount = amount % 10;
    var nickel = Math.floor(amount / 5);
    var penny = Math.floor(amount % 5);
    $("#quarters").val(quarter);
    $("#dimes").val(dime);
    $("#nickels").val(nickel);
    $("#pennies").val(penny);
};
$("#calculate").click( function() {
    var amount = $("#cents").val();
    if(amount >= 99 || amount <= 0 ){
        alert("Please enter a valid number between 0 and 99");
    }
    else{
       makeTheChange(amount);
    }
}); // end click() method
    
    // set focus on cents text box on initial load
    $("#cents").focus();
}); // end ready() method