"use strict";
$(document).ready(function(){
    var getCurrentMonthText = function(currentMonth) {
        if (currentMonth === 0) { return "January"; }
        else if (currentMonth === 1) { return "February"; }
        else if (currentMonth === 2) { return "March"; }
        else if (currentMonth === 3) { return "April"; }
        else if (currentMonth === 4) { return "May"; }
        else if (currentMonth === 5) { return "June"; }
        else if (currentMonth === 6) { return "July"; }
        else if (currentMonth === 7) { return "August"; }
        else if (currentMonth === 8) { return "September"; }
        else if (currentMonth === 9) { return "October"; }
        else if (currentMonth === 10) { return "November"; }
        else if (currentMonth === 11) { return "December"; }
    };

    var getLastDayofTheMonth = function(currentMonth) {
		var endOfMonth = new Date();
		endOfMonth.setMonth(currentMonth + 1);
		endOfMonth.setDate(0);
		return endOfMonth.getDate();
    };
	var date = new Date();
	var month = date.getMonth();
	var year = date.getFullYear();
    $("#month_year").text(getCurrentMonthText(month) + " " + year);
	var lastDay = getLastDayofTheMonth(month);
	date.setDate(1);
	var htmlString = "";
	htmlString = htmlString.concat("<tr>");
	var start = 1;
	var count = 1;
	for(var i = 0; i < date.getDay(); i++)
	{
		htmlString = htmlString.concat("<td> </td>");
		count++;
	}
	for(i = date.getDay(); i < 7; i++)
	{
		htmlString = htmlString.concat("<td>" + start.toString() + "</td>");
		start++;
		count++;
	}
	htmlString = htmlString.concat("</tr><tr>");
	for(i = 0; i < 7; i++)
	{
		htmlString = htmlString.concat("<td>" + start.toString() + "</td>");
		start++;
		count++;
	}
	htmlString = htmlString.concat("</tr><tr>");
	for(i = 0; i < 7; i++)
	{
		htmlString = htmlString.concat("<td>" + start.toString() + "</td>");
		start++;
		count++;
	}
	htmlString = htmlString.concat("</tr><tr>");
	for(i = 0; i < 7; i++)
	{
		htmlString = htmlString.concat("<td>" + start.toString() + "</td>");
		start++;
		count++;
	}
	htmlString = htmlString.concat("</tr><tr>");
	for(i = start; i <= lastDay; i++)
	{
		htmlString = htmlString.concat("<td>" + start.toString() + "</td>");
		start++;
		count++;
	}
	while(count <= 35)
	{
		htmlString = htmlString.concat("<td> </td>");
		count++;
	}
	htmlString = htmlString.concat("</tr>");
	$("#calendar").append(htmlString);
});